﻿namespace xmlFormulasSchool
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.txtFileName = new System.Windows.Forms.TextBox();
            this.txtFormulaName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDomain = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtFormula = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtp1 = new System.Windows.Forms.TextBox();
            this.txtp2 = new System.Windows.Forms.TextBox();
            this.txtp3 = new System.Windows.Forms.TextBox();
            this.txtp4 = new System.Windows.Forms.TextBox();
            this.txtp5 = new System.Windows.Forms.TextBox();
            this.txtdt5 = new System.Windows.Forms.TextBox();
            this.txtdt4 = new System.Windows.Forms.TextBox();
            this.txtdt3 = new System.Windows.Forms.TextBox();
            this.txtdt2 = new System.Windows.Forms.TextBox();
            this.txtdt1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtdt10 = new System.Windows.Forms.TextBox();
            this.txtdt9 = new System.Windows.Forms.TextBox();
            this.txtdt8 = new System.Windows.Forms.TextBox();
            this.txtdt7 = new System.Windows.Forms.TextBox();
            this.txtdt6 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtp10 = new System.Windows.Forms.TextBox();
            this.txtp9 = new System.Windows.Forms.TextBox();
            this.txtp8 = new System.Windows.Forms.TextBox();
            this.txtp7 = new System.Windows.Forms.TextBox();
            this.txtp6 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.exp10 = new System.Windows.Forms.TextBox();
            this.exp9 = new System.Windows.Forms.TextBox();
            this.exp8 = new System.Windows.Forms.TextBox();
            this.exp7 = new System.Windows.Forms.TextBox();
            this.exp6 = new System.Windows.Forms.TextBox();
            this.exp5 = new System.Windows.Forms.TextBox();
            this.exp4 = new System.Windows.Forms.TextBox();
            this.exp3 = new System.Windows.Forms.TextBox();
            this.exp2 = new System.Windows.Forms.TextBox();
            this.exp1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(14, 23);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "createXML";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtFileName
            // 
            this.txtFileName.Location = new System.Drawing.Point(95, 25);
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.Size = new System.Drawing.Size(438, 20);
            this.txtFileName.TabIndex = 1;
            this.txtFileName.Text = "formula";
            // 
            // txtFormulaName
            // 
            this.txtFormulaName.Location = new System.Drawing.Point(93, 69);
            this.txtFormulaName.Name = "txtFormulaName";
            this.txtFormulaName.Size = new System.Drawing.Size(440, 20);
            this.txtFormulaName.TabIndex = 2;
            this.txtFormulaName.Text = "denumire";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Formula name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Domain";
            // 
            // txtDomain
            // 
            this.txtDomain.Location = new System.Drawing.Point(93, 102);
            this.txtDomain.Name = "txtDomain";
            this.txtDomain.Size = new System.Drawing.Size(440, 20);
            this.txtDomain.TabIndex = 5;
            this.txtDomain.Text = "domeniul";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Formula";
            // 
            // txtFormula
            // 
            this.txtFormula.Location = new System.Drawing.Point(93, 130);
            this.txtFormula.Multiline = true;
            this.txtFormula.Name = "txtFormula";
            this.txtFormula.Size = new System.Drawing.Size(440, 51);
            this.txtFormula.TabIndex = 7;
            this.txtFormula.Text = "public void goto(int x, int y){ Left  =x ; Top = y;}";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 197);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "param1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 223);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "param2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 249);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "param3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 275);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "param4";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(11, 301);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "param5";
            // 
            // txtp1
            // 
            this.txtp1.Location = new System.Drawing.Point(67, 197);
            this.txtp1.Name = "txtp1";
            this.txtp1.Size = new System.Drawing.Size(100, 20);
            this.txtp1.TabIndex = 13;
            this.txtp1.Text = "x";
            // 
            // txtp2
            // 
            this.txtp2.Location = new System.Drawing.Point(67, 223);
            this.txtp2.Name = "txtp2";
            this.txtp2.Size = new System.Drawing.Size(100, 20);
            this.txtp2.TabIndex = 14;
            this.txtp2.Text = "y";
            // 
            // txtp3
            // 
            this.txtp3.Location = new System.Drawing.Point(65, 249);
            this.txtp3.Name = "txtp3";
            this.txtp3.Size = new System.Drawing.Size(100, 20);
            this.txtp3.TabIndex = 15;
            // 
            // txtp4
            // 
            this.txtp4.Location = new System.Drawing.Point(67, 275);
            this.txtp4.Name = "txtp4";
            this.txtp4.Size = new System.Drawing.Size(100, 20);
            this.txtp4.TabIndex = 16;
            // 
            // txtp5
            // 
            this.txtp5.Location = new System.Drawing.Point(67, 301);
            this.txtp5.Name = "txtp5";
            this.txtp5.Size = new System.Drawing.Size(100, 20);
            this.txtp5.TabIndex = 17;
            // 
            // txtdt5
            // 
            this.txtdt5.Location = new System.Drawing.Point(432, 301);
            this.txtdt5.Name = "txtdt5";
            this.txtdt5.Size = new System.Drawing.Size(100, 20);
            this.txtdt5.TabIndex = 27;
            // 
            // txtdt4
            // 
            this.txtdt4.Location = new System.Drawing.Point(432, 275);
            this.txtdt4.Name = "txtdt4";
            this.txtdt4.Size = new System.Drawing.Size(100, 20);
            this.txtdt4.TabIndex = 26;
            // 
            // txtdt3
            // 
            this.txtdt3.Location = new System.Drawing.Point(430, 249);
            this.txtdt3.Name = "txtdt3";
            this.txtdt3.Size = new System.Drawing.Size(100, 20);
            this.txtdt3.TabIndex = 25;
            // 
            // txtdt2
            // 
            this.txtdt2.Location = new System.Drawing.Point(432, 223);
            this.txtdt2.Name = "txtdt2";
            this.txtdt2.Size = new System.Drawing.Size(100, 20);
            this.txtdt2.TabIndex = 24;
            this.txtdt2.Text = "int";
            // 
            // txtdt1
            // 
            this.txtdt1.Location = new System.Drawing.Point(432, 197);
            this.txtdt1.Name = "txtdt1";
            this.txtdt1.Size = new System.Drawing.Size(100, 20);
            this.txtdt1.TabIndex = 23;
            this.txtdt1.Text = "int";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(343, 301);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 13);
            this.label9.TabIndex = 22;
            this.label9.Text = "datatypeparam5";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(343, 275);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 13);
            this.label10.TabIndex = 21;
            this.label10.Text = "datatypeparam4";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(343, 249);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 13);
            this.label11.TabIndex = 20;
            this.label11.Text = "datatypeparam3";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(343, 223);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(83, 13);
            this.label12.TabIndex = 19;
            this.label12.Text = "datatypeparam2";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(343, 197);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 13);
            this.label13.TabIndex = 18;
            this.label13.Text = "datatypeparam1";
            // 
            // txtdt10
            // 
            this.txtdt10.Location = new System.Drawing.Point(432, 431);
            this.txtdt10.Name = "txtdt10";
            this.txtdt10.Size = new System.Drawing.Size(100, 20);
            this.txtdt10.TabIndex = 47;
            // 
            // txtdt9
            // 
            this.txtdt9.Location = new System.Drawing.Point(432, 405);
            this.txtdt9.Name = "txtdt9";
            this.txtdt9.Size = new System.Drawing.Size(100, 20);
            this.txtdt9.TabIndex = 46;
            // 
            // txtdt8
            // 
            this.txtdt8.Location = new System.Drawing.Point(430, 379);
            this.txtdt8.Name = "txtdt8";
            this.txtdt8.Size = new System.Drawing.Size(100, 20);
            this.txtdt8.TabIndex = 45;
            // 
            // txtdt7
            // 
            this.txtdt7.Location = new System.Drawing.Point(432, 353);
            this.txtdt7.Name = "txtdt7";
            this.txtdt7.Size = new System.Drawing.Size(100, 20);
            this.txtdt7.TabIndex = 44;
            // 
            // txtdt6
            // 
            this.txtdt6.Location = new System.Drawing.Point(432, 327);
            this.txtdt6.Name = "txtdt6";
            this.txtdt6.Size = new System.Drawing.Size(100, 20);
            this.txtdt6.TabIndex = 43;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(343, 431);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(89, 13);
            this.label14.TabIndex = 42;
            this.label14.Text = "datatypeparam10";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(343, 405);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(83, 13);
            this.label15.TabIndex = 41;
            this.label15.Text = "datatypeparam9";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(343, 379);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(83, 13);
            this.label16.TabIndex = 40;
            this.label16.Text = "datatypeparam8";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(343, 353);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(83, 13);
            this.label17.TabIndex = 39;
            this.label17.Text = "datatypeparam7";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(343, 327);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(83, 13);
            this.label18.TabIndex = 38;
            this.label18.Text = "datatypeparam6";
            // 
            // txtp10
            // 
            this.txtp10.Location = new System.Drawing.Point(67, 431);
            this.txtp10.Name = "txtp10";
            this.txtp10.Size = new System.Drawing.Size(100, 20);
            this.txtp10.TabIndex = 37;
            // 
            // txtp9
            // 
            this.txtp9.Location = new System.Drawing.Point(67, 405);
            this.txtp9.Name = "txtp9";
            this.txtp9.Size = new System.Drawing.Size(100, 20);
            this.txtp9.TabIndex = 36;
            // 
            // txtp8
            // 
            this.txtp8.Location = new System.Drawing.Point(65, 379);
            this.txtp8.Name = "txtp8";
            this.txtp8.Size = new System.Drawing.Size(100, 20);
            this.txtp8.TabIndex = 35;
            // 
            // txtp7
            // 
            this.txtp7.Location = new System.Drawing.Point(67, 353);
            this.txtp7.Name = "txtp7";
            this.txtp7.Size = new System.Drawing.Size(100, 20);
            this.txtp7.TabIndex = 34;
            // 
            // txtp6
            // 
            this.txtp6.Location = new System.Drawing.Point(67, 327);
            this.txtp6.Name = "txtp6";
            this.txtp6.Size = new System.Drawing.Size(100, 20);
            this.txtp6.TabIndex = 33;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(11, 431);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(48, 13);
            this.label19.TabIndex = 32;
            this.label19.Text = "param10";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(9, 405);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(42, 13);
            this.label20.TabIndex = 31;
            this.label20.Text = "param9";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(9, 379);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(42, 13);
            this.label21.TabIndex = 30;
            this.label21.Text = "param8";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(9, 353);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(42, 13);
            this.label22.TabIndex = 29;
            this.label22.Text = "param7";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(9, 327);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(42, 13);
            this.label23.TabIndex = 28;
            this.label23.Text = "param6";
            // 
            // exp10
            // 
            this.exp10.Location = new System.Drawing.Point(173, 431);
            this.exp10.Name = "exp10";
            this.exp10.Size = new System.Drawing.Size(164, 20);
            this.exp10.TabIndex = 57;
            // 
            // exp9
            // 
            this.exp9.Location = new System.Drawing.Point(173, 405);
            this.exp9.Name = "exp9";
            this.exp9.Size = new System.Drawing.Size(164, 20);
            this.exp9.TabIndex = 56;
            // 
            // exp8
            // 
            this.exp8.Location = new System.Drawing.Point(171, 379);
            this.exp8.Name = "exp8";
            this.exp8.Size = new System.Drawing.Size(164, 20);
            this.exp8.TabIndex = 55;
            // 
            // exp7
            // 
            this.exp7.Location = new System.Drawing.Point(173, 353);
            this.exp7.Name = "exp7";
            this.exp7.Size = new System.Drawing.Size(164, 20);
            this.exp7.TabIndex = 54;
            // 
            // exp6
            // 
            this.exp6.Location = new System.Drawing.Point(173, 327);
            this.exp6.Name = "exp6";
            this.exp6.Size = new System.Drawing.Size(164, 20);
            this.exp6.TabIndex = 53;
            // 
            // exp5
            // 
            this.exp5.Location = new System.Drawing.Point(173, 301);
            this.exp5.Name = "exp5";
            this.exp5.Size = new System.Drawing.Size(164, 20);
            this.exp5.TabIndex = 52;
            // 
            // exp4
            // 
            this.exp4.Location = new System.Drawing.Point(173, 275);
            this.exp4.Name = "exp4";
            this.exp4.Size = new System.Drawing.Size(164, 20);
            this.exp4.TabIndex = 51;
            // 
            // exp3
            // 
            this.exp3.Location = new System.Drawing.Point(171, 249);
            this.exp3.Name = "exp3";
            this.exp3.Size = new System.Drawing.Size(164, 20);
            this.exp3.TabIndex = 50;
            // 
            // exp2
            // 
            this.exp2.Location = new System.Drawing.Point(173, 223);
            this.exp2.Name = "exp2";
            this.exp2.Size = new System.Drawing.Size(164, 20);
            this.exp2.TabIndex = 49;
            this.exp2.Text = "pozitia y verticala";
            // 
            // exp1
            // 
            this.exp1.Location = new System.Drawing.Point(173, 197);
            this.exp1.Name = "exp1";
            this.exp1.Size = new System.Drawing.Size(164, 20);
            this.exp1.TabIndex = 48;
            this.exp1.Text = "positia x orizonatala";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(548, 482);
            this.Controls.Add(this.exp10);
            this.Controls.Add(this.exp9);
            this.Controls.Add(this.exp8);
            this.Controls.Add(this.exp7);
            this.Controls.Add(this.exp6);
            this.Controls.Add(this.exp5);
            this.Controls.Add(this.exp4);
            this.Controls.Add(this.exp3);
            this.Controls.Add(this.exp2);
            this.Controls.Add(this.exp1);
            this.Controls.Add(this.txtdt10);
            this.Controls.Add(this.txtdt9);
            this.Controls.Add(this.txtdt8);
            this.Controls.Add(this.txtdt7);
            this.Controls.Add(this.txtdt6);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtp10);
            this.Controls.Add(this.txtp9);
            this.Controls.Add(this.txtp8);
            this.Controls.Add(this.txtp7);
            this.Controls.Add(this.txtp6);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.txtdt5);
            this.Controls.Add(this.txtdt4);
            this.Controls.Add(this.txtdt3);
            this.Controls.Add(this.txtdt2);
            this.Controls.Add(this.txtdt1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtp5);
            this.Controls.Add(this.txtp4);
            this.Controls.Add(this.txtp3);
            this.Controls.Add(this.txtp2);
            this.Controls.Add(this.txtp1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtFormula);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtDomain);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtFormulaName);
            this.Controls.Add(this.txtFileName);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtFileName;
        private System.Windows.Forms.TextBox txtFormulaName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDomain;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtFormula;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtp1;
        private System.Windows.Forms.TextBox txtp2;
        private System.Windows.Forms.TextBox txtp3;
        private System.Windows.Forms.TextBox txtp4;
        private System.Windows.Forms.TextBox txtp5;
        private System.Windows.Forms.TextBox txtdt5;
        private System.Windows.Forms.TextBox txtdt4;
        private System.Windows.Forms.TextBox txtdt3;
        private System.Windows.Forms.TextBox txtdt2;
        private System.Windows.Forms.TextBox txtdt1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtdt10;
        private System.Windows.Forms.TextBox txtdt9;
        private System.Windows.Forms.TextBox txtdt8;
        private System.Windows.Forms.TextBox txtdt7;
        private System.Windows.Forms.TextBox txtdt6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtp10;
        private System.Windows.Forms.TextBox txtp9;
        private System.Windows.Forms.TextBox txtp8;
        private System.Windows.Forms.TextBox txtp7;
        private System.Windows.Forms.TextBox txtp6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox exp10;
        private System.Windows.Forms.TextBox exp9;
        private System.Windows.Forms.TextBox exp8;
        private System.Windows.Forms.TextBox exp7;
        private System.Windows.Forms.TextBox exp6;
        private System.Windows.Forms.TextBox exp5;
        private System.Windows.Forms.TextBox exp4;
        private System.Windows.Forms.TextBox exp3;
        private System.Windows.Forms.TextBox exp2;
        private System.Windows.Forms.TextBox exp1;
    }
}

